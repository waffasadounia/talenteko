// postcss.config.js
// 👉 Tailwind v4 utilise ce plugin PostCSS unique
module.exports = {
  plugins: {
    '@tailwindcss/postcss': {}, // charge Tailwind
  },
};
